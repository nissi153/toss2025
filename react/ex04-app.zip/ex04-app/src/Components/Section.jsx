export default function Section() {
  return (
    <div>
      <div></div>
    </div>
  );
}
