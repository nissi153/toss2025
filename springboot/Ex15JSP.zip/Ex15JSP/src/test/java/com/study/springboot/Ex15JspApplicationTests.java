package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex15JspApplicationTests {

	@Test
	void contextLoads() {
	}

}
