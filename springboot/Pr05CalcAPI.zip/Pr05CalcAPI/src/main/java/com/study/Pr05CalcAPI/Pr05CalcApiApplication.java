package com.study.Pr05CalcAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr05CalcApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr05CalcApiApplication.class, args);
	}

}
