package com.study.Pr05CalcAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr05CalcApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
