package com.study.Ex31Docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex31DockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
