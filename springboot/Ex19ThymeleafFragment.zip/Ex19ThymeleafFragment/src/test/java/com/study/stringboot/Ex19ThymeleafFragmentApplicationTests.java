package com.study.stringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex19ThymeleafFragmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
