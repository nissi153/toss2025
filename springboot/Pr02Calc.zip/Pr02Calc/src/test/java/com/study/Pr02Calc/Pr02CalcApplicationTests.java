package com.study.Pr02Calc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr02CalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
