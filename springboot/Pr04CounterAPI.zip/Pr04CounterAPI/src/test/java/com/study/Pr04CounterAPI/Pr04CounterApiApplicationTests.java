package com.study.Pr04CounterAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr04CounterApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
