package com.study.Pr04CounterAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr04CounterApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr04CounterApiApplication.class, args);
	}

}
