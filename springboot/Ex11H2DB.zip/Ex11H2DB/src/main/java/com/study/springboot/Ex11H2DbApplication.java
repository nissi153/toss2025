package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex11H2DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex11H2DbApplication.class, args);
	}

}
