package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex11H2DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
