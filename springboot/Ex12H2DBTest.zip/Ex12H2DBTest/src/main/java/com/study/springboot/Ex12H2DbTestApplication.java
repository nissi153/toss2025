package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex12H2DbTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex12H2DbTestApplication.class, args);
	}

}
