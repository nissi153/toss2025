package com.study.stringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex05StaticWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
