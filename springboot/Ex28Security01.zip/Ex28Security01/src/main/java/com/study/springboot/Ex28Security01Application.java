package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex28Security01Application {

	public static void main(String[] args) {
		SpringApplication.run(Ex28Security01Application.class, args);
	}

}
